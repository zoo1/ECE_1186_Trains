import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

class SocketListener extends Thread {
	
	int socketListenerNumber = 8005;
	
	public void run() {
		while (true) {
			try (
				ServerSocket serverSocket =	new ServerSocket(socketListenerNumber);
				Socket clientSocket = serverSocket.accept();     
				BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
				PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
			) {
				out.println("Connection accepted.");
				StringBuilder completeInput = new StringBuilder("");
				String inputLine;
				while ((inputLine = in.readLine()) != null) {
					completeInput.append(inputLine);
				}
				if (completeInput.toString().contains("Train Model")) {
					// Send block data to Zach.
					if (TrackModelJustin.blockList.peek() != null) {
						TrackModelData block = TrackModelJustin.blockList.remove();
						block.sendToTrainModel(0);
						if (block.parameters.containsKey("isStop")) {
							StopData stop = TrackModelJustin.stopList.remove();
							if (stop != null) {
								stop.sendToTrainController(0);
							}
						}
					}
				}
							
				// System.out.println(completeInput.toString());
			} catch (IOException e) {
				System.out.println("Error: Port listening exception on port " + socketListenerNumber + ".");
				System.out.println(e.getMessage());
			}
		}
	}
}