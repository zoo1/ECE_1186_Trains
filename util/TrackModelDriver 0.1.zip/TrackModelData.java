import java.util.*;

public class TrackModelData {
	
	public String senderComponent = "Track Model";
	public Hashtable<String, String> parameters;
	
	public TrackModelData() {
		parameters = new Hashtable<String, String>();
	}

	public void sendToTrainModel(int id) {
		String sendString = senderComponent + " : " + id + " : set, ";
		for (String key : parameters.keySet()) {
			if (!key.equals("isStop")) {
				sendString += key + " = " + parameters.get(key) + ", ";
			}
		}
		sendString = sendString.substring(0, sendString.length() - 2);
		System.out.println(sendString);
		// MessageLibrary.sendMessage("localhost", 8007, sendString);
	}
	
}