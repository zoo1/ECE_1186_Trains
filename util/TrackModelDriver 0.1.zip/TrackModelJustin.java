import java.util.*;

public class TrackModelJustin {
	
	public static LinkedList<TrackModelData> blockList;
	public static LinkedList<StopData> stopList;
	
	public static void main(String[] arg) {
		init();
		SocketListener listener = new SocketListener();
		listener.start();
	}
	
	private static void init() {
		blockList = new LinkedList<TrackModelData>();
		stopList = new LinkedList<StopData>();
		
		TrackModelData data1 = new TrackModelData();
		data1.parameters.put("authority", "3");
		data1.parameters.put("speed", "32");
		data1.parameters.put("passengers", "22");
		data1.parameters.put("isStop", "22");
		blockList.add(data1);
		
		TrackModelData data2 = new TrackModelData();
		data2.parameters.put("authority", "2");
		data2.parameters.put("speed", "29");
		data2.parameters.put("passengers", "12");
		blockList.add(data2);
		
		TrackModelData data3 = new TrackModelData();
		data3.parameters.put("authority", "99");
		data3.parameters.put("speed", "99");
		data3.parameters.put("passengers", "99");
		data3.parameters.put("isStop", "whatever");
		blockList.add(data3);
		
		TrackModelData data4 = new TrackModelData();
		data4.parameters.put("authority", "11");
		data4.parameters.put("speed", "22");
		data4.parameters.put("passengers", "33");
		blockList.add(data4);
		
		TrackModelData data5 = new TrackModelData();
		data5.parameters.put("authority", "11");
		data5.parameters.put("speed", "22");
		data5.parameters.put("passengers", "33");
		blockList.add(data5);
		
		StopData stop1 = new StopData();
		stop1.parameters.put("distance", "1.45");
		stop1.parameters.put("dwell", "90");
		stopList.add(stop1);
		
		StopData stop2 = new StopData();
		stop2.parameters.put("distance", "3.45");
		stop2.parameters.put("dwell", "30");
		stopList.add(stop2);
		
		// Add to queue.
	}

}